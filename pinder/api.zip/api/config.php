<?php
// $connect = mysql_connect('localhost', 'root', '');
// $database = mysql_select_db('pinder', $connect);

$connect = new mysqli("localhost", "root", "", "pinder");